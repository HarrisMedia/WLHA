// Kexy - Platform detection only
// Full context comes from Vision mode (screenshot capture from device)
import { Platform } from 'react-native';

console.log('[KEXY] Platform: ' + Platform.OS);
