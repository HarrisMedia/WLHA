// Service to fetch now playing information from WLHA Radio
// This would typically connect to your station's metadata API

export class NowPlayingService {
  static async fetchNowPlaying() {
    try {
      // Replace with your actual metadata API endpoint
      // Most radio stations provide metadata through Icecast/Shoutcast APIs
      const response = await fetch('https://your-radio-api.com/nowplaying', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        return {
          song: data.title || 'Unknown Song',
          artist: data.artist || 'WLHA Radio',
          album: data.album || 'Live Stream',
          artwork: data.artwork_url || null,
          duration: data.duration || null,
          startTime: data.started_at || new Date().toISOString(),
        };
      }
    } catch (error) {
      console.log('Metadata fetch error:', error);
    }

    // Fallback data when API is unavailable
    return {
      song: 'Live Programming',
      artist: 'WLHA Radio',
      album: 'The Big 64',
      artwork: null,
      duration: null,
      startTime: new Date().toISOString(),
    };
  }

  // Simulate metadata updates for demo purposes
  static getMockNowPlaying() {
    const mockTracks = [
      {
        song: 'Sweet Caroline',
        artist: 'Neil Diamond',
        album: 'Brother Love\'s Travelling Salvation Show',
        artwork: null,
      },
      {
        song: 'Don\'t Stop Believin\'',
        artist: 'Journey',
        album: 'Escape',
        artwork: null,
      },
      {
        song: 'Bohemian Rhapsody',
        artist: 'Queen',
        album: 'A Night at the Opera',
        artwork: null,
      },
      {
        song: 'Hotel California',
        artist: 'Eagles',
        album: 'Hotel California',
        artwork: null,
      },
      {
        song: 'Imagine',
        artist: 'John Lennon',
        album: 'Imagine',
        artwork: null,
      },
      {
        song: 'The Big 64 Morning Show',
        artist: 'WLHA Radio',
        album: 'Live Programming',
        artwork: null,
      }
    ];

    return mockTracks[Math.floor(Math.random() * mockTracks.length)];
  }

  // Start polling for metadata updates
  static startMetadataPolling(callback, intervalMs = 30000) {
    const poll = async () => {
      const nowPlaying = await this.fetchNowPlaying();
      callback(nowPlaying);
    };

    // Initial fetch
    poll();

    // Set up periodic polling
    return setInterval(poll, intervalMs);
  }

  static stopMetadataPolling(intervalId) {
    if (intervalId) {
      clearInterval(intervalId);
    }
  }
}