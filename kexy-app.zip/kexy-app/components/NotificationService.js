// Background audio notification service for WLHA Radio
// Fallback implementation for Expo Snack compatibility
import { Platform, Alert } from 'react-native';

export class NotificationService {
  static notificationId = null;
  static isSupported = false;

  // Setup notification permissions - fallback implementation
  static async setupNotifications() {
    try {
      // In Expo Snack, expo-notifications may not be available
      // This is a fallback that gracefully handles the missing dependency
      this.isSupported = false;
      console.log('Notifications not available in this environment - using fallback');
      return false;
    } catch (error) {
      console.log('Notification setup fallback:', error);
      this.isSupported = false;
      return false;
    }
  }

  // Show persistent notification for radio playback - fallback implementation
  static async showPlaybackNotification(nowPlaying, isPlaying) {
    try {
      if (!this.isSupported) {
        // In production, this would show actual notifications
        // For now, we'll just log the notification content
        console.log('📻 Notification (fallback):', {
          title: 'WLHA Radio - The Big 64',
          body: isPlaying 
            ? `♪ ${nowPlaying.song} - ${nowPlaying.artist}` 
            : 'Radio Paused - Tap to resume',
          isPlaying: isPlaying
        });
        return null;
      }

      // Real implementation would use expo-notifications here
      return null;
    } catch (error) {
      console.log('Notification error (fallback):', error);
      return null;
    }
  }

  // Update existing notification - fallback implementation
  static async updatePlaybackNotification(nowPlaying, isPlaying) {
    return this.showPlaybackNotification(nowPlaying, isPlaying);
  }

  // Clear playback notification - fallback implementation
  static async clearPlaybackNotification() {
    try {
      if (this.notificationId) {
        console.log('📻 Clearing notification (fallback)');
        this.notificationId = null;
      }
    } catch (error) {
      console.log('Clear notification error (fallback):', error);
    }
  }

  // Handle notification interactions - fallback implementation
  static setupNotificationListeners(onPlayPause) {
    // In a real app with expo-notifications, this would set up listeners
    // For fallback, we'll return a dummy subscription
    console.log('📻 Notification listeners setup (fallback)');
    
    return {
      remove: () => console.log('Notification listener removed (fallback)')
    };
  }

  // Cleanup - fallback implementation
  static cleanup() {
    console.log('📻 Notification service cleanup (fallback)');
    this.clearPlaybackNotification();
  }
}